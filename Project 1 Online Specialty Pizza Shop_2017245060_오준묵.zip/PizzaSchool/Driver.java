package PizzaSchool;

public class Driver {
    public static void main(String[] args) {

        OrderItem o = new OrderItem();
        o.displayPizzaMenu();
        o.displayPayment();



    }
}
